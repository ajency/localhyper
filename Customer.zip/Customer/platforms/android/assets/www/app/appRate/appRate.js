angular.module('LocalHyper.appRate', []).controller('appRateCtrl', [
  '$scope', '$cordovaAppRate', function($scope, $cordovaAppRate) {
    return document.addEventListener("deviceready", function() {
      return $cordovaAppRate.promptForRating(true).then(function(result) {});
    });
  }
]).config([
  '$stateProvider', '$cordovaAppRateProvider', function($stateProvider, $cordovaAppRateProvider) {
    document.addEventListener("deviceready", function() {
      var popupInfo;
      AppRate.preferences.useLanguage = 'en';
      popupInfo = {};
      popupInfo.title = "Rate Us";
      popupInfo.message = "In Love with the app ? Give us five star!";
      popupInfo.cancelButtonLabel = "No, thanks";
      popupInfo.laterButtonLabel = "Remind Me Later";
      popupInfo.rateButtonLabel = "Rate Now";
      AppRate.preferences.customLocale = popupInfo;
      AppRate.preferences.openStoreInApp = false;
      AppRate.preferences.storeAppURL.ios = '849930087';
      return AppRate.preferences.storeAppURL.android = 'market://details?id=com.jabong.android';
    });
    return $stateProvider.state('rate-us', {
      url: '/rate-us',
      parent: 'main',
      cache: false,
      views: {
        "appContent": {
          controller: 'appRateCtrl',
          templateUrl: 'views/appRate.html'
        }
      }
    });
  }
]);
