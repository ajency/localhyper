/** Automatically generated file. DO NOT MODIFY */
package com.local.hyper.alpha;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}